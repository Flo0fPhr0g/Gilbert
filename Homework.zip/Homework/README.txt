This is ur religion homework,
it fills up ALL directorys with random files, and then shuts down ur pc with the message: "GILBERT HAS SEEN ENOUGH, ITS TIME
 FOR EVERYONE TO GO NOW
enjoy :)